export class EnrollModel {
    constructor(
        public name: String,
        public email: String,
        public phone: String,
        public address: String,
        public qualification: String,
        public passout: String,
        public skillset: String,
        public employmentStatus: String,
        public technologyTraining: String,
        public year: String,
        public course:String,
        public fee: String,
        public id: String,
        public image: String,
        public exitmark: String,
        public status: String
    ) {}
}