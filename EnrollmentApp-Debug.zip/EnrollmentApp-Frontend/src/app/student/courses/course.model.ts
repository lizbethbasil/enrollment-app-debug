export class CourseModel {
    constructor(
        public name: String,
        public technology: String,
        public intro: String,
        public image: String
    ) {}
}